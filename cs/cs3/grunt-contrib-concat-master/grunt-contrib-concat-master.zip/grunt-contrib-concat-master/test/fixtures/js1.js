var x = 1;


/**
 * Redefine "x"
 * @type {number}
 */
x = 10;
